const a={GoogleSub:"founderGoogleSub",Email:"founderEmail",FounderId:"founderId",GmailLastSweepAt:"gmailLastSweepAt",DriveLastSweepAt:"driveLastSweepAt",LocalLastSweepAt:"localLastSweepAt"};async function o(e){return(await chrome.storage.local.get(e))[e]}async function s(e,t){await chrome.storage.local.set({[e]:t})}export{a as S,o as g,s};
//# sourceMappingURL=storage-Dkc67sV_.js.map
