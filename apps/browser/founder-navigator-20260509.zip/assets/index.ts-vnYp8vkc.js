import{C as g,a as p}from"./api-BlkcEQMj.js";const l="startupstate-styles",m=`
[data-startupstate-gap-strip] {
	position: sticky;
	top: 0;
	z-index: 99999;
	background: linear-gradient(135deg, #1d4ed8, #4338ca);
	color: white;
	padding: 10px 16px;
	font: 600 14px/1.4 -apple-system, system-ui, sans-serif;
	display: flex;
	gap: 12px;
	align-items: center;
}
[data-startupstate-gap-strip] .gap-link {
	background: rgba(255,255,255,0.15);
	color: white;
	padding: 4px 10px;
	border-radius: 999px;
	text-decoration: none;
	font-size: 12px;
}
[data-startupstate-badge] {
	display: inline-block;
	padding: 2px 8px;
	border-radius: 999px;
	font: 600 11px/1.2 -apple-system, system-ui, sans-serif;
	margin-left: 6px;
}
[data-startupstate-badge="top"] { background: #dcfce7; color: #166534; }
[data-startupstate-badge="strong"] { background: #dbeafe; color: #1e40af; }
[data-startupstate-badge="maybe"] { background: #fef3c7; color: #92400e; }

[data-startupstate-side-panel] {
	position: fixed;
	right: 16px;
	top: 80px;
	width: 320px;
	max-height: 70vh;
	overflow-y: auto;
	background: white;
	border: 1px solid #e2e8f0;
	border-radius: 12px;
	box-shadow: 0 10px 30px rgba(15,23,42,0.18);
	padding: 16px;
	z-index: 99999;
	font: 13px/1.5 -apple-system, system-ui, sans-serif;
	color: #0f172a;
}
[data-startupstate-side-panel] h3 {
	margin: 0 0 8px;
	font-size: 14px;
}
[data-startupstate-side-panel] .citation {
	background: #f1f5f9;
	border-left: 3px solid #3b82f6;
	padding: 8px 10px;
	border-radius: 6px;
	margin: 8px 0;
}
[data-startupstate-side-panel] .citation .source {
	font-weight: 600;
	color: #475569;
	font-size: 11px;
	text-transform: uppercase;
	letter-spacing: 0.05em;
	margin-bottom: 4px;
}
[data-startupstate-side-panel] button.close {
	float: right;
	border: none;
	background: transparent;
	font-size: 18px;
	cursor: pointer;
	color: #64748b;
}

[data-startupstate-banner] {
	background: #fef9c3;
	border: 1px solid #fde047;
	color: #854d0e;
	padding: 10px 14px;
	border-radius: 8px;
	margin: 12px 16px;
	font: 13px -apple-system, system-ui, sans-serif;
}
`;function x(){if(document.getElementById(l))return;const t=document.createElement("style");t.id=l,t.dataset.startupstate="true",t.textContent=m,document.head.appendChild(t)}async function h(){return new Promise(t=>{chrome.runtime.sendMessage({type:"founderNavigator/getIdentity"},e=>{t(e??{})})})}function f(t){for(;t.firstChild;)t.removeChild(t.firstChild)}function u(){if(document.querySelector("[data-startupstate-banner]"))return;const t=document.createElement("div");t.dataset.startupstateBanner="true",t.textContent="Connect your business signals in the extension popup to personalize this page.",document.body.insertBefore(t,document.body.firstChild)}function b(t,e){if(t.length===0)return;let n=document.querySelector("[data-startupstate-gap-strip]");n||(n=document.createElement("div"),n.dataset.startupstateGapStrip="true",document.body.insertBefore(n,document.body.firstChild)),f(n);const r=document.createElement("span");r.textContent=`${t.length} step${t.length===1?"":"s"} you haven't completed yet:`,n.appendChild(r);for(const a of t.slice(0,3)){const s=e.get(a),o=document.createElement("a");o.className="gap-link",o.textContent=a,o.href=(s==null?void 0:s.link)??"#",o.target="_blank",o.rel="noreferrer",n.appendChild(o)}}function y(t){const e=document.querySelector(`a[href*="${t}"]`);return e?e.closest("article, .card, .resource, li, section")??e.parentElement:null}function C(t,e){if(t.querySelector("[data-startupstate-badge]"))return;const n=document.createElement("span");n.dataset.startupstateBadge=e.relevance,n.textContent=e.relevance==="top"?"Top match":e.relevance==="strong"?"Strong match":"Maybe",(t.querySelector("h1, h2, h3, h4, .title, a")??t).appendChild(n),t.addEventListener("mouseenter",()=>k(e))}function k(t){let e=document.querySelector("[data-startupstate-side-panel]");e||(e=document.createElement("div"),e.dataset.startupstateSidePanel="true",document.body.appendChild(e)),f(e);const n=document.createElement("button");n.className="close",n.textContent="×",n.onclick=()=>e==null?void 0:e.remove(),e.appendChild(n);const r=document.createElement("h3");if(r.textContent=t.title,e.appendChild(r),t.citations.length===0){const a=document.createElement("p");a.textContent="No citations available yet — connect more signals.",e.appendChild(a);return}for(const a of t.citations){const s=document.createElement("div");s.className="citation";const o=document.createElement("div");o.className="source",o.textContent=`${a.source} · ${a.title}`,s.appendChild(o);const i=document.createElement("div");i.textContent=a.snippet,s.appendChild(i),e.appendChild(s)}}async function v(){if(!location.hostname.includes("startup.utah.gov"))return;x();const t=await h();if(!t.googleSub){u();return}const e=new g("https://exuberant-gazelle-121.convex.cloud"),n=await e.query(p.startupState.auth.getFounderByGoogleSub,{googleSub:t.googleSub});if(!n||n.version===0){u(),await e.close();return}chrome.runtime.sendMessage({type:"founderNavigator/getAccessToken"},async r=>{if(!(r!=null&&r.accessToken)){console.warn("[founder-navigator] no access token; skipping match"),await e.close();return}try{const a={accessToken:r.accessToken,limit:25},s=await e.action(p.startupState.resources.matchResources,a),o=new Map;for(const i of n.gaps){const d=s.find(c=>`${c.title} ${c.description}`.toLowerCase().includes(i.toLowerCase()));d&&o.set(i,d)}b(n.gaps,o);for(const i of s){const d=y(i.link);d&&C(d,i)}}catch(a){console.warn("[founder-navigator] match failed",a)}finally{await e.close()}})}v().catch(t=>{console.warn("[founder-navigator] fatal:",t)});
//# sourceMappingURL=index.ts-vnYp8vkc.js.map
